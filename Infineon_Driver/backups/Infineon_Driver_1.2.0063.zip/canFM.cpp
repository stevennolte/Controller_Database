#include "canFM.h"

CanFM::CanFM(){}


// class CanFM{
//   public:
//     uint16_t serialNum = 0;
//     uint64_t msgTimer = 0;
//     uint8_t sourceAddress = 255;
//     float flowrate = 0;
//     uint32_t flowcnt = 0;
//     uint8_t meterState = 0;
//     CanFM(){}
// };