#include "Arduino.h"
#include "relayControl.h"



RelayControl::RelayControl(uint8_t killPin, uint8_t bfPin)  {
  this->killPin = killPin;
  this->bfPin = bfPin;
  
}

void RelayControl::init(){
  pinMode(killPin, OUTPUT);
  pinMode(bfPin, OUTPUT);
  startTask();
}

// Task handler, runs in a separate task
void RelayControl::taskHandler(void *param) {
    // Cast the param back to the ClassA object
    RelayControl *instance = static_cast<RelayControl *>(param);
    instance->continuousLoop();  // Call the member function
}

// Start the FreeRTOS task
void RelayControl::startTask() {
    xTaskCreate(
        taskHandler,   // Task function
        "TaskA",       // Name of the task
        4096,          // Stack size (in words)
        this,          // Pass the current instance as the task parameter
        1,             // Priority of the task
        NULL           // Task handle (not needed)
    );
}

// Function to run in parallel
void RelayControl::continuousLoop() {
  while (true) {
    
    vTaskDelay(10 / portTICK_PERIOD_MS);  // Delay for 500ms to control the speed of the loop
  }
}
