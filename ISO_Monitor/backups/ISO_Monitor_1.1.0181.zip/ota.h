#ifndef ota_h
#define ota_h

#include "Arduino.h"


void OtaPullCallback(int offset, int totallength);


#endif